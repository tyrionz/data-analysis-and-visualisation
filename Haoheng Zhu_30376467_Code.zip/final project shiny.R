
require('shiny')
require('leaflet')
require('leaflet.minicharts')
require("shinyBS")

require('gganimate')
require('gifski')
require('av')

require('plyr')
require('dplyr')
require('ggplot2')
require('tidyverse')
require('plotly')


data_All_state <- read.csv('data_All_state.csv')
full_df <- read.csv('full_df.csv')
full_df$Year = as.character(full_df$Year)
full_df$Year = as.Date(full_df$Year, format="%Y-%m-%d")


ui <- navbarPage("Energy consumption in Australia",
                 # Introduction page
                 tabPanel("Introduction",fluidPage(
                   
                   titlePanel("FIT5147 Final project Data Visualization."),
                   hr(),
                   p( "Author: Haoheng Zhu"),
                   hr(),
                   # App Description
                   p("Did Australia's energy consumption preference change over the past few decades? 
                     Do people consume more Renewable energy or Non-Renewable energy throughout the recent decades?
                     Data studied by this project can be found at:", 
                     tags$a(href = 'https://www.energy.gov.au/government-priorities/energy-data/australian-energy-statistics', 
                            'Bureau of Statistics Australia', target = '_blank')),
                   hr(),
                   strong("Please try to address the following questions from the next 3 visualizations accordingly:", style = "color:MediumSeaGreen"),
                   p("Motion Chart) How does energy consumtion changes along with GSP (gross state product) throughout the decades?", style = "color:blue"),
                   p("Map & mini charts) How does the proportion of renewable and non-renewable energy consumption change over the decades? ", style = "color:Tomato"),
                   p("Animated Line Chart) Is there a correlation between renewable and non-renewable energy consumption? If so, for which states?", style = "color:Tomato"),
                   hr(),
                   strong("by Haoheng Zhu", style = "color:MediumSeaGreen"),
                   hr(),
                   strong("The visualizations in the next 3 pages are animated and interactive. Please play with it and don't forget to click on the 
                          graph to display some hidden message that I would like to convey to you.", style = "color:black"),
                   
                   
                   
                 )
                 
                 ), 
                 
                 # new page
                 tabPanel("Motion Chart",
                          fluidPage(
                            titlePanel("How does energy consumption change in each state?
                                       Watch how energy consumption change with GSP.
                                       Then explore with your own interest.
                                       Also don't forget to click on the chart for tips on my findings."),
                            sidebarLayout(
                              sidebarPanel(
                                selectInput(inputId = "yaxis",  
                                            label = "Select Y axis",  
                                            choices = c("Energy consumption" = "Energy.consumption", 
                                                        "Energy consumption per capita" = "Energy.consumption.per.capita",
                                                        "Energy intensity" = "Energy.intensity",
                                                        "Energy productivity" = "Energy.productivity"),
                                            selected = "Energy consumption"),
                                bsTooltip("y axis", "choose from drop down list",
                                          "right", options = list(container = "body")),
                                
                                
                                selectInput(inputId = "xaxis", 
                                                   label = "Select X axis", 
                                                   choices = c("GSP" = "GSP",
                                                               "Population" = "Population"),
                                                   selected = "GSP"),
                                bsTooltip("x axis", "choose from drop down list",
                                          "right", options = list(container = "body")),
                                
                                
                                selectInput(inputId = "size", 
                                            label = "Select bubble size", 
                                            choices = c("GSP" = "GSP",
                                                        "Population" = "Population"),
                                            selected = "Population"),
                                bsTooltip("bubble size", "choose from drop down list",
                                          "right", options = list(container = "body")),
                              ),
                              mainPanel(plotlyOutput("motion_chart")
                                                    
                                                    
                              )
                              
                            )
                          )
                 ), 
                 
                 
                 # new page
                 tabPanel("Map & mini charts",
                          fluidPage(
                            titlePanel("Visualize on map. Let's see how the proportion of Renewable energy change over the decades.
                                       Please feel free to change the chart type.
                                       Also don't forget to click on the chart for tips on my findings."),
                            sidebarLayout(
                              sidebarPanel(
                                
                                selectInput(inputId = "chart_type", 
                                                   label = "Select chart type", 
                                                   choices = c("Polar-area" = "polar-area",
                                                               "Bar" = "bar",
                                                               "Pie" = "pie",
                                                               "Polar-radius" = "polar-radius"),
                                                   selected = "Polar-area"),
                                bsTooltip("chart type", "choose from drop down list",
                                          "right", options = list(container = "body")),
                               
                              ),
                              mainPanel(leafletOutput("leafminicharts")
                                        
                              )
                              
                            )
                            
                          )
                          
                 ),
                 
                 # new page
                 tabPanel("Animated line chart",
                          fluidPage(
                            titlePanel("Line chart for more specific comparison.To better compare the changes, I applied log transform for the data.
                                      Let's see how the proportion of Renewable energy change over the decades for each state.
                                      This could take 15 secs to generate the animation, please wait.
                                       Please feel free to change the state to compare.
                                       Also don't forget to click on the chart for tips on my findings."),
                            sidebarLayout(
                              sidebarPanel(
                                
                                selectInput(inputId = "state", 
                                            label = "Select state", 
                                            choices = c("NSW" = "NSW",
                                                        "TAS" = "TAS",
                                                        "VIC" = "VIC",
                                                        "QLD" = "QLD",
                                                        "WA" = "WA",
                                                        "SA" = "SA",
                                                        "NT" = "NT"
                                                        ),
                                            
                                            selected = "SA"),
                                
                                bsTooltip("state", "choose from drop down list",
                                          "right", options = list(container = "body")),
                                
                              ),
                              mainPanel(imageOutput("line_animate", width = "200%", height = "400px")
                                        
                              )
                              
                            )
                            
                          )
                          
                 )
)





# server.R ----
server <- function(input, output, session) {
  
  # motion chart with plotly
  output$motion_chart <- renderPlotly({
    
    p_plot <- ggplot(data_All_state,
                     aes_string(
                       x=input$xaxis,
                       y=input$yaxis,
                       color="State"
                     )) %>%
                + geom_point(aes_string(
                  size=input$size,
                  frame="Year",
                  ids="State"
                ))
    ggplotly(p_plot)
  })
  
  output$leafminicharts <- renderLeaflet({
    leaflet(data = full_df) %>%
      addTiles() %>%
      addMinicharts(
        full_df$lon, full_df$lat,
        type = input$chart_type,
        chartdata = full_df[,c('NonR','Renewable')],
        time = full_df$Year,
        width = 45,
        height = 45
      )
    
    
    
    
  })
  
  output$line_animate <- renderImage({
    
    outfile <- tempfile(fileext='.gif')
    
    p <- ggplot(full_df %>% filter(State %in% input$state), aes_string(x="Year")) +
      geom_line(aes(y=NonR, col='Non-renewable'), size=2, show.legend = TRUE) +
      geom_line(aes(y=Renewable, col='Renewable'), size=2, show.legend = TRUE) +
      scale_color_manual(values=c("#ff9933", "#006400")) +
      labs(title = 'Non-renewable vs Renewable', 
           x = 'Year', y = 'Energy Consumption') +
      theme(plot.title = element_text(hjust = 0.5)) +
      transition_reveal(Year) +
      coord_cartesian(clip = 'off') + 
      scale_y_log10()+
      theme(legend.title = element_text(colour="black", size=20, 
                                        face="bold")) +
      theme(legend.background = element_rect(fill="lightblue",
                                             size=0.5, linetype="solid", 
                                             colour ="darkblue"))+
      guides(fill =
               guide_legend(
                 title.theme = element_text(
                   size = 15,
                   face = "italic",
                   colour = "red",
                   angle = 0
                 )
               )
      ) +
      ease_aes('cubic-in-out')
    
    anim_save("outfile.gif", animate(p, fps = 10, width = 1000, height = 600))
    
    list(src = "outfile.gif",
         contentType = 'image/gif'
    ) 
    
    
  }, deleteFile = TRUE)
  
  addPopover(session, "motion_chart", "Conclusion", content = paste0('Throughout the decades, all states follow the same pattern that the greater the
                                                                     GSP, the greater its energy consumption.'), trigger = "click")
  
  addPopover(session, "leafminicharts", "Conclusion", content = paste0('Although the total energy consumption keeps increasing, we can see that, in NSW the 
                                                                       proportion of renewable energy increases greatly among all.
                                                                       There seems to have a correlation between Renewable and Non-renewable energy,
                                                                       but what is it? Please check out the next visualization to compare the correlation for
                                                                       each state.'), trigger = "click")
  
  addPopover(session, "line_animate", "Conclusion", content = paste0('Among all states, "SA, NSW, VIC" have the most obvious negative correlation between
                                                                    Renewable and Non-renewable energy consumption.'), trigger = "click")
  
  
}





shinyApp(ui = ui, server = server)
