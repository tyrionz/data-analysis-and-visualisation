
require('readxl')
require('VIM')
require('plyr')
require('dplyr')
require('ggplot2')
require('forcats')
require('tidyverse')

# libraries for motion chart
require('plotly')
#require('gapminder')

#require('googleVis')

# libraries for cartogram
#require('cartogram')
#require('broom')
#require('tweenr')

# library for animated line chart
require('gganimate')
require('gifski')
require('av')
#require('maptools')
#require('viridis')

require('ggmap')
require('sp')
#require('devtools')

# interactive map
require('leaflet')
require('leaflet.minicharts')



# Step 1: preprocess data for visualization
data3 <- read_xlsx('australian_energy_statistics_2019_table_o.xlsx',  col_names = FALSE, sheet = 11, range = 'B5:I25')


# swap row and column in a dataframe
data4 <- data.frame(t(data3[-1]), check.names = TRUE)

# use 'for loop' to change column names
col4 <- data3[1]
counter <- 0
for (i in pull(col4)) {
  counter = counter+1
  names(data4)[counter] <- i
}

# change column 1 name
names(data4)[1] <- 'state'

# remove column 2,3,10,11
data4 <- data4[-c(2,3,10,11)]

# reset row names (reset row index)
rownames(data4) <- NULL

# fix factor order
b <- fct_inorder(data4$`Total renewable`)

# change column data type
a <- levels(b)
data4$`Total renewable` <- as.numeric(a)

# prepare for motion chart for table b
dataB2 <- read_xlsx('australian_energy_statistics_2019_table_b.xlsx',  col_names = FALSE, sheet = 2, range = 'B5:H64')

# remove 2nd row
dataB2 <- dataB2[-c(2),]

# rename columns
colnames(dataB2) <- NULL
row1 <- dataB2[1,]
row1[,1] <- 'Year'

counter <- 0
for (i in row1) {
  counter = counter+1
  names(dataB2)[counter] <- i
}

# remove 1st row
dataB2 <- dataB2[-c(1),]

# trim Year to 4 digits
dataB2$Year <- strtrim(dataB2$Year, 4)

# check datatype
sapply(dataB2,class)

# change datatypes
dataB2$Year <- as.numeric(as.character(dataB2$Year))
dataB2$Population <- as.numeric(as.character(dataB2$Population))
dataB2$GDP <- as.numeric(as.character(dataB2$GDP))
dataB2$`Energy consumption` <- as.numeric(as.character(dataB2$`Energy consumption`))
dataB2$`Energy consumption per capita` <- as.numeric(as.character(dataB2$`Energy consumption per capita`))
dataB2$`Energy intensity` <- as.numeric(as.character(dataB2$`Energy intensity`))
dataB2$`Energy productivity` <- as.numeric(as.character(dataB2$`Energy productivity`))

#for (i in 1:length(colnames(dataB2))) {

#  dataB2[,i] <- as.numeric(as.character(dataB2[,i]))
#}

#dataB2[1] <- as.numeric(as.character(dataB2[,1]))

# get the states data
# get NSW
dataB3 <- read_xlsx('australian_energy_statistics_2019_table_b.xlsx',  col_names = FALSE, sheet = 3, range = 'B5:H64')

# remove 2nd row
dataB3 <- dataB3[-c(2),]

# rename columns
colnames(dataB3) <- NULL
row1 <- dataB3[1,]
row1[,1] <- 'Year'

counter <- 0
for (i in row1) {
  counter = counter+1
  names(dataB3)[counter] <- i
}

# remove 1st row
dataB3 <- dataB3[-c(1),]

# trim Year to 4 digits
dataB3$Year <- strtrim(dataB3$Year, 4)

# remove NA rows
dataB3 <- dataB3[-c(1:29),]

# change datatypes
dataB3$State <- 'NSW'
dataB3$Year <- as.numeric(as.character(dataB3$Year))
dataB3$Population <- as.numeric(as.character(dataB3$Population))
dataB3$GSP <- as.numeric(as.character(dataB3$GSP))
dataB3$`Energy consumption` <- as.numeric(as.character(dataB3$`Energy consumption`))
dataB3$`Energy consumption per capita` <- as.numeric(as.character(dataB3$`Energy consumption per capita`))
dataB3$`Energy intensity` <- as.numeric(as.character(dataB3$`Energy intensity`))
dataB3$`Energy productivity` <- as.numeric(as.character(dataB3$`Energy productivity`))

# change column order
dataB3 <- dataB3[, c(8, 1:7)]


# get VIC
dataB4 <- read_xlsx('australian_energy_statistics_2019_table_b.xlsx',  col_names = FALSE, sheet = 4, range = 'B5:H64')

# remove 2nd row
dataB4 <- dataB4[-c(2),]

# rename columns
colnames(dataB4) <- NULL
row1 <- dataB4[1,]
row1[,1] <- 'Year'

counter <- 0
for (i in row1) {
  counter = counter+1
  names(dataB4)[counter] <- i
}

# remove 1st row
dataB4 <- dataB4[-c(1),]

# trim Year to 4 digits
dataB4$Year <- strtrim(dataB4$Year, 4)

# remove NA rows
dataB4 <- dataB4[-c(1:29),]

# change datatypes
dataB4$State <- 'VIC'
dataB4$Year <- as.numeric(as.character(dataB4$Year))
dataB4$Population <- as.numeric(as.character(dataB4$Population))
dataB4$GSP <- as.numeric(as.character(dataB4$GSP))
dataB4$`Energy consumption` <- as.numeric(as.character(dataB4$`Energy consumption`))
dataB4$`Energy consumption per capita` <- as.numeric(as.character(dataB4$`Energy consumption per capita`))
dataB4$`Energy intensity` <- as.numeric(as.character(dataB4$`Energy intensity`))
dataB4$`Energy productivity` <- as.numeric(as.character(dataB4$`Energy productivity`))

# change column order
dataB4 <- dataB4[, c(8, 1:7)]

# get QLD
dataB5 <- read_xlsx('australian_energy_statistics_2019_table_b.xlsx',  col_names = FALSE, sheet = 5, range = 'B5:H64')

# remove 2nd row
dataB5 <- dataB5[-c(2),]

# rename columns
colnames(dataB5) <- NULL
row1 <- dataB5[1,]
row1[,1] <- 'Year'

counter <- 0
for (i in row1) {
  counter = counter+1
  names(dataB5)[counter] <- i
}

# remove 1st row
dataB5 <- dataB5[-c(1),]

# trim Year to 4 digits
dataB5$Year <- strtrim(dataB5$Year, 4)

# remove NA rows
dataB5 <- dataB5[-c(1:29),]

# change datatypes
dataB5$State <- 'QLD'
dataB5$Year <- as.numeric(as.character(dataB5$Year))
dataB5$Population <- as.numeric(as.character(dataB5$Population))
dataB5$GSP <- as.numeric(as.character(dataB5$GSP))
dataB5$`Energy consumption` <- as.numeric(as.character(dataB5$`Energy consumption`))
dataB5$`Energy consumption per capita` <- as.numeric(as.character(dataB5$`Energy consumption per capita`))
dataB5$`Energy intensity` <- as.numeric(as.character(dataB5$`Energy intensity`))
dataB5$`Energy productivity` <- as.numeric(as.character(dataB5$`Energy productivity`))
# change column order
dataB5 <- dataB5[, c(8, 1:7)]

# get WA
dataB6 <- read_xlsx('australian_energy_statistics_2019_table_b.xlsx',  col_names = FALSE, sheet = 6, range = 'B5:H64')

# remove 2nd row
dataB6 <- dataB6[-c(2),]

# rename columns
colnames(dataB6) <- NULL
row1 <- dataB6[1,]
row1[,1] <- 'Year'

counter <- 0
for (i in row1) {
  counter = counter+1
  names(dataB6)[counter] <- i
}

# remove 1st row
dataB6 <- dataB6[-c(1),]

# trim Year to 4 digits
dataB6$Year <- strtrim(dataB6$Year, 4)

# remove NA rows
dataB6 <- dataB6[-c(1:29),]

# change datatypes
dataB6$State <- 'WA'
dataB6$Year <- as.numeric(as.character(dataB6$Year))
dataB6$Population <- as.numeric(as.character(dataB6$Population))
dataB6$GSP <- as.numeric(as.character(dataB6$GSP))
dataB6$`Energy consumption` <- as.numeric(as.character(dataB6$`Energy consumption`))
dataB6$`Energy consumption per capita` <- as.numeric(as.character(dataB6$`Energy consumption per capita`))
dataB6$`Energy intensity` <- as.numeric(as.character(dataB6$`Energy intensity`))
dataB6$`Energy productivity` <- as.numeric(as.character(dataB6$`Energy productivity`))

# change column order
dataB6 <- dataB6[, c(8, 1:7)]


# get SA
dataB7 <- read_xlsx('australian_energy_statistics_2019_table_b.xlsx',  col_names = FALSE, sheet = 7, range = 'B5:H64')

# remove 2nd row
dataB7 <- dataB7[-c(2),]

# rename columns
colnames(dataB7) <- NULL
row1 <- dataB7[1,]
row1[,1] <- 'Year'

counter <- 0
for (i in row1) {
  counter = counter+1
  names(dataB7)[counter] <- i
}

# remove 1st row
dataB7 <- dataB7[-c(1),]

# trim Year to 4 digits
dataB7$Year <- strtrim(dataB7$Year, 4)

# remove NA rows
dataB7 <- dataB7[-c(1:29),]

# change datatypes
dataB7$State <- 'SA'
dataB7$Year <- as.numeric(as.character(dataB7$Year))
dataB7$Population <- as.numeric(as.character(dataB7$Population))
dataB7$GSP <- as.numeric(as.character(dataB7$GSP))
dataB7$`Energy consumption` <- as.numeric(as.character(dataB7$`Energy consumption`))
dataB7$`Energy consumption per capita` <- as.numeric(as.character(dataB7$`Energy consumption per capita`))
dataB7$`Energy intensity` <- as.numeric(as.character(dataB7$`Energy intensity`))
dataB7$`Energy productivity` <- as.numeric(as.character(dataB7$`Energy productivity`))
# change column order
dataB7 <- dataB7[, c(8, 1:7)]

# get TAS
dataB8 <- read_xlsx('australian_energy_statistics_2019_table_b.xlsx',  col_names = FALSE, sheet = 8, range = 'B5:H64')

# remove 2nd row
dataB8 <- dataB8[-c(2),]

# rename columns
colnames(dataB8) <- NULL
row1 <- dataB8[1,]
row1[,1] <- 'Year'

counter <- 0
for (i in row1) {
  counter = counter+1
  names(dataB8)[counter] <- i
}

# remove 1st row
dataB8 <- dataB8[-c(1),]

# trim Year to 4 digits
dataB8$Year <- strtrim(dataB8$Year, 4)

# remove NA rows
dataB8 <- dataB8[-c(1:29),]

# change datatypes
dataB8$State <- 'TAS'
dataB8$Year <- as.numeric(as.character(dataB8$Year))
dataB8$Population <- as.numeric(as.character(dataB8$Population))
dataB8$GSP <- as.numeric(as.character(dataB8$GSP))
dataB8$`Energy consumption` <- as.numeric(as.character(dataB8$`Energy consumption`))
dataB8$`Energy consumption per capita` <- as.numeric(as.character(dataB8$`Energy consumption per capita`))
dataB8$`Energy intensity` <- as.numeric(as.character(dataB8$`Energy intensity`))
dataB8$`Energy productivity` <- as.numeric(as.character(dataB8$`Energy productivity`))

# change column order
dataB8 <- dataB8[, c(8, 1:7)]



# get NT
dataB9 <- read_xlsx('australian_energy_statistics_2019_table_b.xlsx',  col_names = FALSE, sheet = 9, range = 'B5:H64')

# remove 2nd row
dataB9 <- dataB9[-c(2),]

# rename columns
colnames(dataB9) <- NULL
row1 <- dataB9[1,]
row1[,1] <- 'Year'

counter <- 0
for (i in row1) {
  counter = counter+1
  names(dataB9)[counter] <- i
}

# remove 1st row
dataB9 <- dataB9[-c(1),]

# trim Year to 4 digits
dataB9$Year <- strtrim(dataB9$Year, 4)

# remove NA rows
dataB9 <- dataB9[-c(1:29),]

# change datatypes
dataB9$State <- 'NT'
dataB9$Year <- as.numeric(as.character(dataB9$Year))
dataB9$Population <- as.numeric(as.character(dataB9$Population))
dataB9$GSP <- as.numeric(as.character(dataB9$GSP))
dataB9$`Energy consumption` <- as.numeric(as.character(dataB9$`Energy consumption`))
dataB9$`Energy consumption per capita` <- as.numeric(as.character(dataB9$`Energy consumption per capita`))
dataB9$`Energy intensity` <- as.numeric(as.character(dataB9$`Energy intensity`))
dataB9$`Energy productivity` <- as.numeric(as.character(dataB9$`Energy productivity`))

# change column order
dataB9 <- dataB9[, c(8, 1:7)]


# concatenate all states dataframe
data_All_state <- rbind.fill(dataB3,dataB4,dataB5,dataB6,dataB7,dataB8,dataB9)





# renewable and non-renewable data from table O
# compare all state's renewable energy production
# NSW
dnsw <- read_xlsx('australian_energy_statistics_2019_table_o.xlsx',  col_names = FALSE, sheet = 4, range = 'B5:L23')

dnsw <- data.frame(t(dnsw[-1]), check.names = TRUE)
dnsw <- dnsw[-c(2:8,10:18)]
rownames(dnsw) <- NULL
names(dnsw) <- c('Year','NonR','Renewable')
dnsw$Year <- as.character(dnsw$Year)
dnsw$Year <- strtrim(dnsw$Year, 4)
dnsw$NonR <- as.numeric(as.character(dnsw$NonR))
dnsw$Renewable <- as.numeric(as.character(dnsw$Renewable))
dnsw$Year <- as.Date(as.character(dnsw$Year),"%Y")

# VIC
dvic <- read_xlsx('australian_energy_statistics_2019_table_o.xlsx',  col_names = FALSE, sheet = 5, range = 'B5:L23')

dvic <- data.frame(t(dvic[-1]), check.names = TRUE)
dvic <- dvic[-c(2:8,10:18)]
rownames(dvic) <- NULL
names(dvic) <- c('Year','NonR','Renewable')
dvic$Year <- as.character(dvic$Year)
dvic$Year <- strtrim(dvic$Year, 4)
dvic$NonR <- as.numeric(as.character(dvic$NonR))
dvic$Renewable <- as.numeric(as.character(dvic$Renewable))
dvic$Year <- as.Date(as.character(dvic$Year),"%Y")

# QLD
dqld <- read_xlsx('australian_energy_statistics_2019_table_o.xlsx',  col_names = FALSE, sheet = 6, range = 'B5:L23')

dqld <- data.frame(t(dqld[-1]), check.names = TRUE)
dqld <- dqld[-c(2:8,10:18)]
rownames(dqld) <- NULL
names(dqld) <- c('Year','NonR','Renewable')
dqld$Year <- as.character(dqld$Year)
dqld$Year <- strtrim(dqld$Year, 4)
dqld$NonR <- as.numeric(as.character(dqld$NonR))
dqld$Renewable <- as.numeric(as.character(dqld$Renewable))
dqld$Year <- as.Date(as.character(dqld$Year),"%Y")

# WA
dwa <- read_xlsx('australian_energy_statistics_2019_table_o.xlsx',  col_names = FALSE, sheet = 7, range = 'B5:L23')

dwa <- data.frame(t(dwa[-1]), check.names = TRUE)
dwa <- dwa[-c(2:8,10:18)]
rownames(dwa) <- NULL
names(dwa) <- c('Year','NonR','Renewable')
dwa$Year <- as.character(dwa$Year)
dwa$Year <- strtrim(dwa$Year, 4)
dwa$NonR <- as.numeric(as.character(dwa$NonR))
dwa$Renewable <- as.numeric(as.character(dwa$Renewable))
dwa$Year <- as.Date(as.character(dwa$Year),"%Y")

# SA
dsa <- read_xlsx('australian_energy_statistics_2019_table_o.xlsx',  col_names = FALSE, sheet = 8, range = 'B5:L23')

dsa <- data.frame(t(dsa[-1]), check.names = TRUE)
dsa <- dsa[-c(2:8,10:18)]
rownames(dsa) <- NULL
names(dsa) <- c('Year','NonR','Renewable')
dsa$Year <- as.character(dsa$Year)
dsa$Year <- strtrim(dsa$Year, 4)
dsa$NonR <- as.numeric(as.character(dsa$NonR))
dsa$Renewable <- as.numeric(as.character(dsa$Renewable))
dsa$Year <- as.Date(as.character(dsa$Year),"%Y")

# TAS
dtas <- read_xlsx('australian_energy_statistics_2019_table_o.xlsx',  col_names = FALSE, sheet = 9, range = 'B5:L23')

dtas <- data.frame(t(dtas[-1]), check.names = TRUE)
dtas <- dtas[-c(2:8,10:18)]
rownames(dtas) <- NULL
names(dtas) <- c('Year','NonR','Renewable')
dtas$Year <- as.character(dtas$Year)
dtas$Year <- strtrim(dtas$Year, 4)
dtas$NonR <- as.numeric(as.character(dtas$NonR))
dtas$Renewable <- as.numeric(as.character(dtas$Renewable))
dtas$Year <- as.Date(as.character(dtas$Year),"%Y")

# NT
dnt <- read_xlsx('australian_energy_statistics_2019_table_o.xlsx',  col_names = FALSE, sheet = 10, range = 'B5:L23')

dnt <- data.frame(t(dnt[-1]), check.names = TRUE)
dnt <- dnt[-c(2:8,10:18)]
rownames(dnt) <- NULL
names(dnt) <- c('Year','NonR','Renewable')
dnt$Year <- as.character(dnt$Year)
dnt$Year <- strtrim(dnt$Year, 4)
dnt$NonR <- as.numeric(as.character(dnt$NonR))
dnt$Renewable <- as.numeric(as.character(dnt$Renewable))
dnt$Year <- as.Date(as.character(dnt$Year),"%Y")









# prepare for australia map
Australia = geocode("Australia")
#myMap <- get_map(location = "Australia", zoom = 4)
register_google(key='AIzaSyCHzSVJWp-tMIUpPlCbbqKUmZQlUTFFGbM')

#ggplotly(ggmap(myMap))

vic_geo <- geocode('VIC, Australia')
nsw_geo <- geocode('NSW, Australia')
qld_geo <- geocode('QLD, Australia')
tas_geo <- geocode('TAS, Australia')
wa_geo <- geocode('WA, Australia')
sa_geo <- geocode('SA, Australia')
nt_geo <- geocode('NT, Australia')


dvic$State = 'VIC'
dvic$lon = vic_geo$lon
dvic$lat = vic_geo$lat

dnsw$State = 'NSW'
dnsw$lon = nsw_geo$lon
dnsw$lat = nsw_geo$lat

dqld$State = 'QLD'
dqld$lon = qld_geo$lon
dqld$lat = qld_geo$lat

dtas$State = 'TAS'
dtas$lon = tas_geo$lon
dtas$lat = tas_geo$lat

dsa$State = 'SA'
dsa$lon = sa_geo$lon
dsa$lat = sa_geo$lat

dwa$State = 'WA'
dwa$lon = wa_geo$lon
dwa$lat = wa_geo$lat

dnt$State = 'NT'
dnt$lon = nt_geo$lon
dnt$lat = nt_geo$lat

full_df <- rbind.fill(dnsw,dvic,dtas,dsa,dnt,dwa,dqld)

# save dataframes as csv files
write.csv(data_All_state,'data_All_state.csv')
write.csv(full_df,'full_df.csv')


# visualize Non-renewable and Renewable energy on map
# leaflet.minicharts
m <- leaflet(data = full_df) %>%
  addTiles() %>%
  addMinicharts(
    full_df$lon, full_df$lat,
    type = 'polar-area',
    chartdata = full_df[,c('Non-Renewable','Renewable')],
    time = full_df$Year,
    width = 45,
    height = 45
  )

m


# animated line chart
p =  
  ggplot(data = dnsw, aes(x=Year)) +
  geom_line(aes(y=NonR, col='Non-renewable'), size=2, show.legend = TRUE) +
  geom_line(aes(y=Renewable, col='Renewable'), size=2, show.legend = TRUE) +
  scale_color_manual(values=c("#ff9933", "#006400")) +
  labs(title = 'Non-renewable vs Renewable', 
       x = 'Year', y = 'Energy Consumption') +
  theme(plot.title = element_text(hjust = 0.5)) +
  transition_reveal(Year) +
  coord_cartesian(clip = 'off') + 
  scale_y_log10()+
  theme(legend.title = element_text(colour="black", size=20, 
                                    face="bold")) +
  theme(legend.background = element_rect(fill="lightblue",
                                         size=0.5, linetype="solid", 
                                         colour ="darkblue"))+
  guides(fill =
           guide_legend(
             title.theme = element_text(
               size = 15,
               face = "italic",
               colour = "red",
               angle = 0
             )
           )
  ) +
  ease_aes('cubic-in-out')

animate(p, fps = 10, width = 800, height = 400)


# ggplotly for motion chart
p_lot <- ggplot(data_All_state, aes(x=GSP, y=`Energy consumption`, color=State)) %>%
  +geom_point(aes(size=Population, frame=Year, ids=State))


ggplotly(p_lot)
















